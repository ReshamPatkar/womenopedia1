package com.example.ytprojects.fluttermentor.flutter_mentor_quiz_app_tut;

import io.flutter.embedding.android.FlutterActivity;

public class MainActivity extends FlutterActivity {
}
