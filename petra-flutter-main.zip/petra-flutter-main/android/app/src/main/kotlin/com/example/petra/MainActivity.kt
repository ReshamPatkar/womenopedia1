package com.example.petra

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
